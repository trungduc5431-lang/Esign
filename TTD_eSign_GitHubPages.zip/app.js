const panel=document.getElementById('panel');
function openPanel(type){
 const content={
 files:`<h2>📁 Tệp</h2><p>Chọn tệp để xem tên và kích thước. Trang này không tự ký hoặc cài ứng dụng.</p><input type="file" id="picker" multiple><div id="list"></div>`,
 profile:`<h2>⚙️ Profile</h2><p>Để cài một mobileconfig, tải file về Safari rồi mở file và làm theo màn hình Cài đặt. Chỉ cài profile từ nguồn bạn tin tưởng.</p>`,
 about:`<h2>ℹ️ TTD eSign</h2><p>Giao diện web tĩnh mẫu cho GitHub Pages. Không yêu cầu máy chủ.</p>`
 }[type];
 panel.innerHTML=content; panel.classList.remove('hidden');
 if(type==='files') document.getElementById('picker').addEventListener('change',e=>{
   document.getElementById('list').innerHTML=[...e.target.files].map(f=>`<p>📄 ${f.name} — ${(f.size/1024).toFixed(1)} KB</p>`).join('');
 });
}
