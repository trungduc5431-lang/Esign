# TTD eSign — GitHub Pages

## Đưa lên GitHub Pages miễn phí

1. Tạo repository mới trên GitHub, ví dụ `ttd-esign`.
2. Upload `index.html`, `style.css`, `app.js` và `README.md`.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch** → branch `main` → folder `/ (root)` → Save.
5. Sau khi triển khai, GitHub sẽ cấp URL dạng:
   `https://TEN-TK.github.io/ttd-esign/`

Đây là website tĩnh. Nó không có chức năng ký IPA, bypass chứng chỉ, né anti-cheat hoặc cài ứng dụng trái với cơ chế bảo mật của iOS.
